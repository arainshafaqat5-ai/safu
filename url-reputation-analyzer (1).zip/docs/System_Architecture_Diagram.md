# System Architecture

```mermaid
graph TD
    A[User / Frontend UI] -->|Input URL| B[React Dashboard]
    B -->|HTTP POST JSON| C[Express Backend API /api/analyze]
    C --> D{URL Parsing Engine}
    D --> E[Domain Intelligence Module]
    D --> F[Reputation & Lexical Analysis]
    
    E --> G[Node DNS Module]
    E --> H[(Mock WHOIS / Trust DB)]
    
    F --> I[Blacklist Engine]
    F --> J[Heuristics Engine]
    
    G --> K[Scoring Engine]
    H --> K
    I --> K
    J --> K
    
    K --> L[Generate JSON Report]
    L --> C
    C --> B
    B --> M[Data Visualization / Recharts]
```
