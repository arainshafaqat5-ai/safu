import React, { useState } from 'react';

interface UrlInputProps {
  onAnalyze: (url: string) => void;
  isLoading: boolean;
}

export function UrlInput({ onAnalyze, isLoading }: UrlInputProps) {
  const [url, setUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!url.trim()) return;

    try {
      let testUrl = url;
      if (!/^https?:\/\//i.test(testUrl)) {
        testUrl = 'http://' + testUrl;
      }
      new URL(testUrl);
      onAnalyze(testUrl);
    } catch (err) {
      // Just pass it as is to API, it'll handle the format error
      onAnalyze(url);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative flex items-center w-full">
      <input
        type="text"
        className="w-full bg-slate-900 border border-slate-700 rounded px-4 py-1.5 text-sm outline-none focus:border-blue-500 transition-colors text-slate-200 placeholder-slate-500 disabled:opacity-50"
        placeholder="Enter URL to analyze (e.g., https://secure-gateway.net/auth)"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        disabled={isLoading}
      />
      <button
        type="submit"
        disabled={isLoading || !url.trim()}
        className="absolute right-1 bg-blue-600 hover:bg-blue-500 text-white text-xs px-3 py-1 rounded font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isLoading ? 'SCANNING...' : 'ANALYZE'}
      </button>
    </form>
  );
}
