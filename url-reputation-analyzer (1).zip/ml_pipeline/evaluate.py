import pandas as pd
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import classification_report, confusion_matrix

def evaluate_model(model_path, test_data_path):
    print("Loading model for evaluation...")
    clf = joblib.load(model_path)
    
    df = pd.read_csv(test_data_path)
    feature_cols = [
        "domain_length", "has_ip", "num_hyphens", 
        "has_suspicious_tld", "suspicious_keywords_count", 
        "is_shortened", "is_https"
    ]
    X_test = df[feature_cols]
    y_test = df["is_malicious"]
    
    print("Running predictions...")
    y_pred = clf.predict(X_test)
    
    print("\n--- Detailed Performance Metrics ---")
    report = classification_report(y_test, y_pred, target_names=["Benign", "Malicious"])
    print(report)
    
    # Generate Confusion Matrix Figure
    cm = confusion_matrix(y_test, y_pred)
    
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", 
                xticklabels=["Benign", "Malicious"],
                yticklabels=["Benign", "Malicious"])
    plt.ylabel('True Classification')
    plt.xlabel('Predicted Classification')
    plt.title('URL Reputation - Confusion Matrix')
    
    fig_path = "confusion_matrix.png"
    plt.savefig(fig_path)
    print(f"\nConfusion Matrix chart successfully saved to {fig_path}")

if __name__ == "__main__":
    evaluate_model("rf_url_model.pkl", "dataset.csv")
