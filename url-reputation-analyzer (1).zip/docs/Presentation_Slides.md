# Presentation Slides

## Slide 1: Title
**URL Reputation Analyzer**
*Detect Phishing, Suspicious Domains, and Security Risks Instantly*

---

## Slide 2: The Problem
* Users face a constant threat of phishing, scams, and malicious URLs.
* Existing tools are either purely corporate or require complex account sign-ups.
* We need immediate insight before clicking: Is this link safe to open?

---

## Slide 3: Project Scope & Objectives
* **URL Input:** Validate, sanitize, and normalize raw inputs.
* **Domain Intelligence:** Extrapolate Host DNS and structural traits.
* **Lexical Analysis:** Check URL lengths, hidden characters, digits.
* **Scoring Engine:** Compute a heavily weighted Trust Score.
* **Visualization:** Serve an intuitive Dashboard showing clear risk breakdown.

---

## Slide 4: System Architecture & Stack
* **Frontend:** React 19, TypeScript, Tailwind CSS, Recharts for visual feedback.
* **Backend API:** Node.js (Express), standard DNS Modules.
* **Methodology:** API validates and computes deterministic risk metrics in under 5 seconds.

---

## Slide 5: The Scoring Engine
Four Primary Baskets:
1.  **SSL Availability** (20%)
2.  **Domain Trust** (25%) - Age, Records
3.  **Security Indicators** (35%) - Length, TLD, Keywords
4.  **Reputation Sources** (20%) - Hardcoded flags for typical malicious properties

---

## Slide 6: Results & Demo
*   Interactive Web Interface detects standard URLs as Safe (80-100).
*   Correctly flags IP-based domains (`http://192.168.0.1`) as High Risk.
*   Gracefully renders dynamic reports via an easy-to-read chart and dial UI.

---

## Slide 7: Future Expansion (Machine Learning)
* Integration of Python Random Forest classifier.
* Ability to feed raw URI string into localized ML container.
* Real-time global threat feeds.
