import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

def train_url_model(data_path, model_path):
    print("Loading preprocessed dataset...")
    df = pd.read_csv(data_path)
    
    # Define feature set and target label
    feature_cols = [
        "domain_length", "has_ip", "num_hyphens", 
        "has_suspicious_tld", "suspicious_keywords_count", 
        "is_shortened", "is_https"
    ]
    X = df[feature_cols]
    y = df["is_malicious"]
    
    # Split dataset
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42
    )
    
    print("Training Random Forest Classifier on URL Heuristics...")
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X_train, y_train)
    
    # Baseline validation
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Validation Accuracy: {acc * 100:.2f}%")
    
    # Export Model
    joblib.dump(clf, model_path)
    print(f"Model successfully saved to {model_path}")

if __name__ == "__main__":
    train_url_model("dataset.csv", "rf_url_model.pkl")
