# Testing Report
## Overview
This document outlines the testing strategy executed for the URL Reputation Analyzer. Testing covers Unit tests of scoring functions, Integrations between the frontend dashboard and Node backend, and structural validation of edge-case URLs.

## Test Cases

| ID  | Description                      | Input                                         | Expected Output                                   | Result |
| --- | --------------------------------- | --------------------------------------------- | ------------------------------------------------- | ------ |
| 1   | Valid Secure Domain               | `https://github.com`                          | Score > 80 (Safe). All passing indicators.        | **Pass** |
| 2   | Implicit HTTP prefixation         | `google.com`                                  | Prepended with `http://`. Score computed properly.| **Pass** |
| 3   | Missing Scheme / Invalid Domain   | `this is not a url`                           | Error: Invalid URL format.                        | **Pass** |
| 4   | IP-Based URL                      | `http://192.168.1.1/login.php`                | Substantial score deduction, High Risk.           | **Pass** |
| 5   | URL Shortener Flagging            | `https://bit.ly/xyz`                          | Deducts 15 points in Security Indicators.         | **Pass** |
| 6   | Suspicious Keyword Detection      | `http://verify-secure-account-update.xyz/`    | Deducts for TLD (.xyz), Keywords (verify), etc.   | **Pass** |

## UI & Performance Checks
1.  **Responsiveness:** Validated on standard Mobile, Tablet, and Desktop breakpoints. Layout scales properly using Tailwind CSS flex grids.
2.  **API Speed:** API guarantees sub-2 second response times.
3.  **Visualization Render:** SVG Gauge and Recharts render deterministically based on report thresholds.
