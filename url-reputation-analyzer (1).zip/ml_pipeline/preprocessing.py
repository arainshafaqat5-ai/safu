import pandas as pd
import re
from urllib.parse import urlparse

def extract_features(url_str):
    """
    Model pre-processing for the security analysis system
    Extracts lexical and structural components from raw URLs.
    """
    try:
        parsed_url = urlparse(url_str)
        hostname = str(parsed_url.hostname)
    except:
        hostname = ""

    # Feature: Domain Length
    domain_length = len(hostname)
    
    # Feature: Has IP
    has_ip = 1 if re.match(r"^(\d{1,3}\.){3}\d{1,3}$", hostname) else 0
    
    # Feature: Number of Hyphens
    num_hyphens = hostname.count("-")
    
    # Feature: Suspicious TLD
    suspicious_tlds = [".xyz", ".click", ".stream", ".gq", ".tk", ".ml", ".cf", ".zip", ".top"]
    has_suspicious_tld = 1 if any(hostname.endswith(tld) for tld in suspicious_tlds) else 0
    
    # Feature: Suspicious Keywords Count
    keywords = ["login", "secure", "account", "update", "banking", "verify", "password", "credential"]
    suspicious_keywords_count = sum(1 for kw in keywords if kw in url_str.lower())
    
    # Feature: Is Shortened
    shorteners = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd"]
    is_shortened = 1 if hostname in shorteners else 0
    
    # Feature: Is HTTPS
    is_https = 1 if url_str.startswith("https") else 0

    return {
        "domain_length": domain_length,
        "has_ip": has_ip,
        "num_hyphens": num_hyphens,
        "has_suspicious_tld": has_suspicious_tld,
        "suspicious_keywords_count": suspicious_keywords_count,
        "is_shortened": is_shortened,
        "is_https": is_https
    }

def preprocess_dataset(input_csv, output_csv):
    df = pd.read_csv(input_csv)
    # Apply feature extraction
    features = pd.DataFrame(df["url"].apply(extract_features).tolist())
    processed_df = pd.concat([df[["url", "is_malicious"]], features], axis=1)
    
    # Drop rows with NaN
    processed_df.dropna(inplace=True)
    
    # Save processed dataframe
    processed_df.to_csv(output_csv, index=False)
    print(f"Pre-processing complete. Saved to {output_csv}")
    print(f"Total valid samples: {len(processed_df)}")

if __name__ == "__main__":
    print("Running preprocessing pipeline...")
    # Example usage:
    # preprocess_dataset("dataset.csv", "processed_dataset.csv")
