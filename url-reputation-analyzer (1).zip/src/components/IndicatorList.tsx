import React from 'react';
import { AnalysisReport } from '../types';

interface IndicatorListProps {
  indicators: AnalysisReport['indicators'];
}

export function IndicatorList({ indicators }: IndicatorListProps) {
  return (
    <div className="space-y-1.5 mt-4">
      <h2 className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-2">Security Indicators</h2>
      {indicators.map((indicator, idx) => (
        <div key={idx} className="flex justify-between items-center bg-slate-900/50 p-2 rounded border border-slate-800/50">
          <span className="text-xs">{indicator.name}</span>
          <span className={`text-[10px] px-1.5 py-0.5 rounded border font-bold ${
            indicator.passed 
              ? 'bg-green-500/20 text-green-400 border-green-500/30'
              : 'bg-red-500/20 text-red-400 border-red-500/30'
          }`}>
            {indicator.passed ? 'CLEAN' : 'FLAGGED'}
          </span>
        </div>
      ))}
    </div>
  );
}
