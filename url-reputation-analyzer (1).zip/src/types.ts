export interface AnalysisReport {
  url: string;
  hostname: string;
  score: number;
  riskLevel: 'Safe' | 'Moderate Risk' | 'High Risk';
  breakdown: {
    ssl: { score: number; max: number };
    domainTrust: { score: number; max: number };
    securityIndicators: { score: number; max: number };
    reputationSources: { score: number; max: number };
  };
  indicators: Array<{
    name: string;
    passed: boolean;
    detail?: string;
  }>;
}
