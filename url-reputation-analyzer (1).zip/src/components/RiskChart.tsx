import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { AnalysisReport } from '../types';

interface RiskChartProps {
  breakdown: AnalysisReport['breakdown'];
}

export function RiskChart({ breakdown }: RiskChartProps) {
  const data = [
    { name: 'SSL', score: breakdown.ssl.score, max: breakdown.ssl.max },
    { name: 'Domain', score: breakdown.domainTrust.score, max: breakdown.domainTrust.max },
    { name: 'Security', score: breakdown.securityIndicators.score, max: breakdown.securityIndicators.max },
    { name: 'Reputation', score: breakdown.reputationSources.score, max: breakdown.reputationSources.max },
  ];

  return (
    <div className="bg-[#1e293b] border border-[#334155] rounded-lg p-4 flex flex-col h-full w-full">
      <h3 className="text-xs font-bold mb-3 flex items-center gap-2 text-white">
        <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
        Score Breakdown
      </h3>
      <div className="flex-1 font-mono text-[10px] min-h-0">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ top: 0, right: 30, left: 10, bottom: 0 }}>
            <XAxis type="number" domain={[0, 40]} hide />
            <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={80} tick={{ fill: '#94a3b8', fontSize: 10, fontFamily: 'monospace' }} />
            <Tooltip 
              cursor={{fill: 'transparent'}}
              contentStyle={{ borderRadius: '4px', border: '1px solid #334155', backgroundColor: '#0f172a', color: '#cbd5e1', fontSize: '10px' }}
              formatter={(value: number, name: string, props: any) => [`${value} / ${props.payload.max}`, 'Score']}
            />
            <Bar dataKey="score" radius={[0, 4, 4, 0]} barSize={16}>
              {data.map((entry, index) => {
                const ratio = entry.score / entry.max;
                let fill = '#22c55e'; // safe
                if (ratio < 0.5) fill = '#ef4444'; // risk
                else if (ratio < 0.8) fill = '#f59e0b'; // warn
                return <Cell key={`cell-${index}`} fill={fill} />;
              })}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
