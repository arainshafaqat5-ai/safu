# URL Reputation Analyzer - Documentation Report

## 1. Introduction
The URL Reputation Analyzer is an automated system designed to evaluate the risk and credibility of a given website link. By analyzing multiple heuristic factors, such as domain age, IP-based characteristics, suspicious keywords, and URL structure, the application provides users with an actionable trust score. 

## 2. System Architecture
The application follows a standard Full-Stack architecture:
*   **Web Server / Backend API:** Built on Node.js/Express. It parses URLs, triggers mock external API verifications (DNS, SSL, Domain Age), and computes the risk score.
*   **Frontend UI:** Built in React + Tailwind CSS. Provides a responsive interactive Dashboard with real-time feedback and dynamic risk visualizations using Recharts.

## 3. Methodology & Scoring Logic
The engine calculates risk based on four weighted categories:
*   **SSL Availability (20%)** - Base check for secure transport.
*   **Domain Trust (25%)** - Investigates domain age and DNS A-record presence.
*   **Security Indicators (35%)** - Flags excessive hyphens, IP-based domains, shortened URLs (bit.ly, t.co), and suspicious keywords (login, bank, verify).
*   **Reputation Sources (20%)** - Cross-references domains against known phishing/malware heuristic parameters.

Outputs fall into three buckets: Safe (80-100), Moderate Risk (50-79), and High Risk (0-49).

## 4. Machine Learning Integration (Conceptual)
The system is designed to incorporate a predictive ML model (Random Forest / LightGBM) trained on a dataset of malicious and benign URLs. The model evaluates lexical features (length, specific characters) and host-based features (DNS records). See the `ml_pipeline` folder for associated training scripts and datasets.

## 5. Security & Limitations
Currently, WHOIS retrieval and external API connections are mocked due to the absence of API keys. A production deployment would seamlessly replace these stubs with active VirusTotal / WHOIS API client invocations.
