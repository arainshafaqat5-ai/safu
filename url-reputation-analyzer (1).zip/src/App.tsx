import { useState } from 'react';
import { UrlInput } from './components/UrlInput';
import { ScoreGauge } from './components/ScoreGauge';
import { RiskChart } from './components/RiskChart';
import { IndicatorList } from './components/IndicatorList';
import { AnalysisReport } from './types';
import { Shield } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [report, setReport] = useState<AnalysisReport | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleAnalyze = async (url: string) => {
    setIsLoading(true);
    setError('');
    
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to analyze URL');
      }
      
      setReport(data);
    } catch (err: any) {
      setError(err.message || 'An error occurred during verification');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen text-slate-200 bg-[#020617] overflow-hidden font-sans selection:bg-blue-900">
      <header className="h-14 bg-[#0f172a] border-b border-[#334155] flex items-center px-4 justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center font-bold text-white">UA</div>
          <h1 className="font-bold tracking-tight text-lg text-white">Reputation<span className="text-blue-400">Shield</span> v2.4</h1>
        </div>
        <div className="flex-1 max-w-2xl px-8">
          <UrlInput onAnalyze={handleAnalyze} isLoading={isLoading} />
        </div>
        <div className="flex items-center gap-4 text-xs font-medium opacity-70 text-slate-200">
          <span className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-green-500"></div> LIVE FEED
          </span>
          <span>API v1.2</span>
        </div>
      </header>

      <main className="flex-1 flex overflow-hidden">
        {/* Left Aside */}
        <aside className="w-72 bg-[#0f172a] border-r border-[#334155] p-4 flex flex-col gap-4 shrink-0 overflow-y-auto">
          {report ? (
             <>
               <ScoreGauge score={report.score} riskLevel={report.riskLevel} />
               <IndicatorList indicators={report.indicators} />
             </>
          ) : (
             <div className="flex flex-col items-center justify-center py-8 text-slate-600 border border-dashed border-slate-700 rounded-lg">
                <Shield className="h-8 w-8 mb-2 opacity-50" />
                <p className="text-xs">Awaiting Analysis</p>
             </div>
          )}
          
          <div className="mt-auto pt-4">
             <div className="text-[10px] font-bold text-slate-500 mb-2">WHOIS DATA SUMMARY</div>
             <div className="font-mono text-[11px] text-slate-400 p-2 bg-slate-950 rounded leading-relaxed border border-slate-800 space-y-1">
               {report ? (
                 <>
                   <p>REG: {report.hostname.includes('.') ? report.hostname.split('.').slice(-2).join('.') : 'Unknown'}</p>
                   <p>ORG: Private Registration</p>
                   <p>LOC: API Proxy, US</p>
                   <p>DNS: Extracted dynamically</p>
                 </>
               ) : (
                 <>
                   <p className="text-slate-600">- Standby mode -</p>
                 </>
               )}
             </div>
          </div>
        </aside>

        {/* Main Content Area */}
        <section className="flex-1 bg-slate-950 flex flex-col p-4 gap-4 overflow-hidden">
          {error && (
            <div className="p-3 bg-red-500/20 text-red-400 border border-red-500/30 rounded text-sm font-bold tracking-wide">
              {error}
            </div>
          )}

          {!report && !isLoading && !error && (
             <div className="flex flex-col items-center justify-center h-full text-slate-700">
                <Shield className="h-20 w-20 mb-4 opacity-50" />
                <p className="text-lg font-bold tracking-widest uppercase">System Ready</p>
                <p className="text-sm">Please input target URL in the header field.</p>
             </div>
          )}

          <AnimatePresence mode="wait">
            {report && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.3 }}
                className="flex flex-col gap-4 h-full"
              >
                <div className="grid grid-cols-2 gap-4 h-[55%] min-h-[250px]">
                  <RiskChart breakdown={report.breakdown} />
                  
                  <div className="bg-[#1e293b] border border-[#334155] rounded-lg p-4 flex flex-col">
                    <h3 className="text-xs font-bold mb-3 flex items-center gap-2 text-white">
                      <span className="w-2 h-2 bg-purple-400 rounded-full"></span>
                      Analysis Summary
                    </h3>
                    <div className="flex-1 grid grid-cols-2 grid-rows-2 gap-1 font-mono text-[10px]">
                       <div className="flex flex-col items-center justify-center bg-slate-900 border border-slate-800 rounded p-1">
                          <span className="text-slate-500 mb-1">SCORE</span>
                          <span className={`text-sm font-bold ${report.score >= 80 ? 'text-green-400' : report.score >= 50 ? 'text-amber-400' : 'text-red-400'}`}>
                             {report.score}/100
                          </span>
                       </div>
                       <div className="flex flex-col items-center justify-center bg-slate-900 border border-slate-800 rounded p-1">
                          <span className="text-slate-500 mb-1">HOSTNAME</span>
                          <span className="text-blue-400 text-xs font-bold truncate w-full text-center px-1">
                             {report.hostname}
                          </span>
                       </div>
                       <div className="flex flex-col items-center justify-center bg-slate-900 border border-slate-800 rounded p-1">
                          <span className="text-slate-500 mb-1">SSL</span>
                          <span className={`${report.breakdown.ssl.score > 0 ? 'text-green-400' : 'text-red-400'} text-xs font-bold`}>
                             {report.breakdown.ssl.score > 0 ? 'PRESENT' : 'ABSENT'}
                          </span>
                       </div>
                       <div className="flex flex-col items-center justify-center bg-slate-900 border border-slate-800 rounded p-1">
                          <span className="text-slate-500 mb-1">RISK CLASS</span>
                          <span className={`text-xs font-bold ${report.riskLevel === 'Safe' ? 'text-green-400' : report.riskLevel === 'High Risk' ? 'text-red-400' : 'text-amber-400'}`}>
                             {report.riskLevel.toUpperCase()}
                          </span>
                       </div>
                    </div>
                  </div>
                </div>

                <div className="bg-[#1e293b] border border-[#334155] rounded-lg p-4 flex-1 flex flex-col overflow-hidden">
                  <h3 className="text-xs font-bold mb-3 text-white">Real-time Processing Log & Security Analysis</h3>
                  <div className="flex-1 font-mono text-[10px] space-y-1 overflow-y-auto p-2 bg-slate-950 rounded border border-[#334155] text-slate-400">
                    <div><span className="text-slate-600">[{new Date().toLocaleTimeString()}]</span> <span className="text-blue-400">INFO:</span> Received payload for `{report.url}`.</div>
                    <div><span className="text-slate-600">[{new Date().toLocaleTimeString()}]</span> <span className="text-blue-400">INFO:</span> Executing DNS resolution heuristics...</div>
                    
                    {report.indicators.map((ind, i) => (
                      <div key={i}>
                        <span className="text-slate-600">[{new Date(Date.now() + i * 200).toLocaleTimeString()}]</span>{' '}
                        {ind.passed ? (
                          <span className="text-green-400">OK:</span>
                        ) : (
                          <span className="text-red-400 text-warn">WARN:</span>
                        )}{' '}
                        {ind.name}
                        {ind.detail && ` -> ${ind.detail}`}
                      </div>
                    ))}
                    
                    <div><span className="text-slate-600">[{new Date(Date.now() + 2000).toLocaleTimeString()}]</span> <span className="text-blue-400">INFO:</span> Classification pipeline finished. Risk assessed as {report.riskLevel}.</div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </section>
      </main>

      <footer className="h-8 bg-slate-900 border-t border-[#334155] flex items-center px-4 justify-between text-[10px] text-slate-500 font-medium shrink-0">
        <div className="flex gap-4">
          <span>SYSTEM STATUS: <span className="text-green-500">OPTIMAL</span></span>
          <span>DB SYNC: <span className="text-green-500">ACTIVE</span></span>
          <span>THREAT INTEL: 104 NEW SIGS</span>
        </div>
        <div>&copy; 2023 REPUTATION SHIELD ANALYTICS • SECURE NODE #082</div>
      </footer>
    </div>
  );
}
