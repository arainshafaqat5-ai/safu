import React from 'react';
import { motion } from 'motion/react';

interface ScoreGaugeProps {
  score: number;
  riskLevel: 'Safe' | 'Moderate Risk' | 'High Risk';
}

export function ScoreGauge({ score, riskLevel }: ScoreGaugeProps) {
  let color = 'text-green-500';
  let bgColor = 'bg-green-500';
  
  if (riskLevel === 'High Risk') {
    color = 'text-red-500';
    bgColor = 'bg-red-500';
  } else if (riskLevel === 'Moderate Risk') {
    color = 'text-amber-500';
    bgColor = 'bg-amber-500';
  }

  return (
    <div className="bg-[#1e293b] border border-[#334155] rounded-lg p-4">
      <h2 className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-2">Reputation Score</h2>
      <div className="flex flex-col items-center justify-center py-2">
        <div className={`text-[48px] font-extrabold tracking-tighter leading-none ${color}`}>
          {score}
        </div>
        <div className={`text-xs font-bold uppercase mt-1 ${color}`}>
          {riskLevel}
        </div>
      </div>
      <div className="w-full bg-slate-700 h-1.5 rounded-full mt-2 overflow-hidden">
        <motion.div 
          className={`h-full ${bgColor}`} 
          initial={{ width: 0 }}
          animate={{ width: `${score}%` }}
          transition={{ duration: 1, ease: "easeOut" }}
        />
      </div>
      <p className="text-[10px] text-slate-400 mt-3 italic">Confidence Interval: 94.2% based on current heuristic patterns.</p>
    </div>
  );
}
