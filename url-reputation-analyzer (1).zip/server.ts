import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dns from "dns/promises";
import https from "https";

const app = express();
const PORT = 3000;

app.use(express.json());

// Check if HTTPS is supported by attempting a request
async function checkHttps(hostname: string): Promise<boolean> {
  return new Promise((resolve) => {
    const req = https.request({
      hostname,
      port: 443,
      method: 'HEAD',
      timeout: 3000
    }, (res) => {
      resolve(res.statusCode !== undefined && res.statusCode < 500);
    });

    req.on('error', () => resolve(false));
    req.on('timeout', () => { req.destroy(); resolve(false); });
    req.end();
  });
}

// Helper functions for URL analysis
function analyzeUrlStructure(urlStr: string) {
  let urlObj;
  try {
    urlObj = new URL(urlStr);
  } catch (e) {
    return null;
  }

  const hostname = urlObj.hostname;
  const isIpBased = /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname);
  const suspiciousTlds = [".xyz", ".click", ".stream", ".gq", ".tk", ".ml", ".cf", ".zip", ".top"];
  const hasSuspiciousTld = suspiciousTlds.some(tld => hostname.endsWith(tld));
  
  // Complexity score (long domains, lots of hyphens, random alphanumeric)
  const lengthScore = hostname.length > 30 ? -10 : 0;
  const hyphenCount = (hostname.match(/-/g) || []).length;
  const hyphenScore = hyphenCount > 2 ? -10 : 0;
  
  const pathLength = urlObj.pathname.length;
  const isShortened = ["bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd"].includes(hostname);

  const keywords = ["login", "secure", "account", "update", "banking", "verify", "password", "credential"];
  const hasSuspiciousKeywords = keywords.some(kw => urlStr.toLowerCase().includes(kw));

  return {
    urlObj,
    isIpBased,
    hasSuspiciousTld,
    lengthScore,
    hyphenScore,
    isShortened,
    hasSuspiciousKeywords,
    pathLength
  };
}

// API Routes
app.post("/api/analyze", async (req, res) => {
  const { url } = req.body;
  if (!url) {
    return res.status(400).json({ error: "URL is required" });
  }

  let fullUrl = url;
  if (!/^https?:\/\//i.test(url)) {
    fullUrl = "http://" + url;
  }

  const urlData = analyzeUrlStructure(fullUrl);
  if (!urlData) {
    return res.status(400).json({ error: "Invalid URL format" });
  }

  const { hostname } = urlData.urlObj;
  
  // Real DNS Check
  let hasDnsRecords = false;
  let ipAddresses: string[] = [];
  try {
    ipAddresses = await dns.resolve4(hostname);
    hasDnsRecords = true;
  } catch (e) {
    // No A records found
  }

  // Real SSL Check
  const hasHttps = await checkHttps(hostname);

  // Scoring Logic (Deterministic based on features)
  let sslScore = hasHttps ? 20 : 0;
  
  // Domain Trust (mocked age and dns)
  // Seed a random number based on hostname string for consistent mock results
  let seed = 0;
  for (let i = 0; i < hostname.length; i++) {
    seed += hostname.charCodeAt(i);
  }
  const mockDomainAgeDays = hasDnsRecords ? (seed * 10) % 5000 : 0; 
  let domainTrust = 0;
  if (mockDomainAgeDays > 365) domainTrust += 15;
  else if (mockDomainAgeDays > 30) domainTrust += 5;
  if (hasDnsRecords) domainTrust += 10;
  if (urlData.hasSuspiciousTld) domainTrust -= 15;

  let securityIndicators = 35;
  if (urlData.isIpBased) securityIndicators -= 25;
  if (urlData.isShortened) securityIndicators -= 15;
  if (urlData.hasSuspiciousKeywords) securityIndicators -= 15;
  if (urlData.hyphenScore < 0) securityIndicators -= 5;
  if (urlData.lengthScore < 0) securityIndicators -= 5;

  let repSources = 20;
  // Mock blacklist check (simulate failure if IP is 127.0.0.1 or domain has "test" or "phish")
  const isBlacklisted = fullUrl.includes("phish") || fullUrl.includes("malware") || urlData.isIpBased;
  if (isBlacklisted) repSources -= 20;

  // Clamp values
  domainTrust = Math.max(0, Math.min(25, domainTrust));
  securityIndicators = Math.max(0, Math.min(35, securityIndicators));
  repSources = Math.max(0, Math.min(20, repSources));

  const totalScore = sslScore + domainTrust + securityIndicators + repSources;

  let riskLevel = "Safe";
  if (totalScore < 50) riskLevel = "High Risk";
  else if (totalScore < 80) riskLevel = "Moderate Risk";

  const report = {
    url: fullUrl,
    hostname,
    score: totalScore,
    riskLevel,
    breakdown: {
      ssl: { score: sslScore, max: 20 },
      domainTrust: { score: domainTrust, max: 25 },
      securityIndicators: { score: securityIndicators, max: 35 },
      reputationSources: { score: repSources, max: 20 }
    },
    indicators: [
      { name: "HTTPS Enabled", passed: sslScore === 20 },
      { name: "DNS Records Found", passed: hasDnsRecords, detail: hasDnsRecords ? ipAddresses.join(", ") : "No A records" },
      { name: "Domain Age", passed: mockDomainAgeDays > 365, detail: `${mockDomainAgeDays} days` },
      { name: "Suspicious TLD", passed: !urlData.hasSuspiciousTld },
      { name: "Suspicious Keywords", passed: !urlData.hasSuspiciousKeywords },
      { name: "IP-Based URL", passed: !urlData.isIpBased },
      { name: "URL Shortener", passed: !urlData.isShortened },
      { name: "Blacklist Status", passed: !isBlacklisted }
    ]
  };

  // Simulate analysis delay
  setTimeout(() => {
    res.json(report);
  }, 1200);
});

// Setup Vite Middleware in Dev
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
